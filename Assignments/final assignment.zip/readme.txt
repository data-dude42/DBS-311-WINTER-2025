DBS311 – Assignment 2: Retail Application
-----------------------------------------

Group Name: DBS311_Assignment2_Group1

Team Members:
- Amardeep Singh Brar
- Paras Singh
- Gaganpreet Kaur

Course Code: DBS311  
Semester: Winter 2025  
Instructor: Sumithra Chandrasekar

Assignment Overview:
--------------------
We developed a fully functional Retail Application using C++ and Oracle PL/SQL for Assignment 2.  
Our application allows users to log in with a customer ID, add up to 5 products to a cart, view a detailed receipt, and choose to either checkout or cancel the order.

All console output has been formatted to match the sample output provided by the instructor.

Files Submitted:
----------------
✅ `DBS311_Assignment2.cpp` – Final source code  
✅ `Procedures.sql` – All PL/SQL stored procedures used  
✅ `Code Screenshot.docx` – Screenshot of the implemented code  
✅ `Output Screenshot.docx` – Screenshot of output from a working test case  
✅ `Procedures Screenshot.docx` – Screenshot of stored procedure execution  
✅ `Changes to SQL Screenshot.docx` – Screenshot showing SQL changes/updates  
✅ `README.txt` – This document  

Oracle Connection Information:
------------------------------
- Username: dbs311_251nra33  
- Password: 26111449  
- Host: myoracle12c.senecacollege.ca:1521/oracle12c  

Stored Procedures Used:
-----------------------
- `find_customer`
- `find_product`
- `add_order`
- `add_order_item`
- `customer_order`
- `display_order_status`
- `cancel_order`

How to Run:
-----------
1. Open `DBS311_Assignment2.cpp` in Visual Studio (x64 → Release Mode).
2. Make sure the Oracle client is installed and `oraocci12.dll` is either:
   - Added to your system PATH, or
   - Placed in the same folder as the executable
3. Compile and run the application.
4. Login with a valid Customer ID and follow the prompts.

Notes:
------
- All functionality has been tested and verified.
- We ensured proper error handling, accurate total formatting, and polished output presentation.
- Final submission is zipped and named as per course instructions.
