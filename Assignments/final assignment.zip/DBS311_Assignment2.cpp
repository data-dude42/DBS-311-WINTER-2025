/********************************
Name: Paras Singh, Amardeep Singh Brar, Gaganpreet Kaur
**********************************/

#include <iostream>
#include <occi.h>
#include <string>
#include <iomanip>

using namespace std;
using namespace oracle::occi;

struct ShoppingCart {
    int product_id;
    double price;
    int quantity;
};

int mainMenu();
int customerLogin(Connection* conn, int customerId);
int addToCart(Connection* conn, ShoppingCart cart[]);
void displayProducts(ShoppingCart cart[], int productCount);
double findProduct(Connection* conn, int product_id);
int checkout(Connection* conn, ShoppingCart cart[], int customerId, int productCount);
void displayOrderStatus(Connection* conn, int orderId, int customerId);
void cancelOrder(Connection* conn, int orderId, int customerId);

int main() {
    Environment* env = nullptr;
    Connection* conn = nullptr;
    string user = "dbs311_251nra33";
    string pass = "26111449";
    string constr = "myoracle12c.senecacollege.ca:1521/oracle12c";
    try {
        env = Environment::createEnvironment(Environment::DEFAULT);
        conn = env->createConnection(user, pass, constr);
        int option = 0;
        int customerId = 0;
        ShoppingCart cart[5] = { 0 };
        int productCount = 0;
        do {
            option = mainMenu();
            if (option == 1) {
                cout << "Enter the customer ID: ";
                cin >> customerId;
                if (customerLogin(conn, customerId)) {
                    productCount = addToCart(conn, cart);
                    if (productCount > 0) {
                        displayProducts(cart, productCount);
                        checkout(conn, cart, customerId, productCount);
                    }
                }
            }
        } while (option != 0);
        cout << "Good bye...!" << endl;
        env->terminateConnection(conn);
        Environment::terminateEnvironment(env);
    }
    catch (SQLException& e) {
        cout << e.getErrorCode() << ": " << e.getMessage() << endl;
    }
    return 0;
}

int mainMenu() {
    int option = -1;
    do {
        cout << "******************** Main Menu ********************" << endl;
        cout << "1)      Login" << endl;
        cout << "0)      Exit" << endl;
        if (option == -1) {
            cout << "Enter an option (0-1): ";
        }
        else {
            cout << "You entered a wrong value. Enter an option (0-1): ";
        }
        cin >> option;
        if (option != 0 && option != 1) option = -2;
    } while (option < 0);
    return option;
}

double findProduct(Connection* conn, int product_id) {
    double price = 0;
    try {
        Statement* stmt = conn->createStatement();
        stmt->setSQL("BEGIN find_product(:1, :2, :3); END;");
        stmt->setInt(1, product_id);
        stmt->registerOutParam(2, Type::OCCISTRING, 50);
        stmt->registerOutParam(3, Type::OCCIDOUBLE);
        stmt->executeUpdate();
        price = stmt->getDouble(3);
        conn->terminateStatement(stmt);
    }
    catch (SQLException& e) {
        cout << e.getErrorCode() << ": " << e.getMessage() << endl;
    }
    return price;
}

int customerLogin(Connection* conn, int customerId) {
    int found = 0;
    try {
        Statement* stmt = conn->createStatement();
        stmt->setSQL("BEGIN find_customer(:1, :2); END;");
        stmt->setInt(1, customerId);
        stmt->registerOutParam(2, Type::OCCIINT);
        stmt->executeUpdate();
        found = stmt->getInt(2);
        conn->terminateStatement(stmt);
        if (found != 1) cout << "The customer does not exist." << endl;
    }
    catch (SQLException& e) {
        cout << e.getErrorCode() << ": " << e.getMessage() << endl;
    }
    return found;
}

int addToCart(Connection* conn, ShoppingCart cart[]) {
    int productCount = 0, productId = 0, quantity = 0, addMore = 1;
    double price = 0;
    cout << "-------------- Add Products to Cart --------------" << endl;
    while (productCount < 5 && addMore == 1) {
        cout << "Enter the product ID: ";
        cin >> productId;
        price = findProduct(conn, productId);
        if (price > 0) {
            cout << "Product Price: " << price << endl;
            cout << "Enter the product Quantity: ";
            cin >> quantity;
            cart[productCount++] = { productId, price, quantity };
            if (productCount < 5) {
                cout << "Enter 1 to add more products or 0 to checkout: ";
                cin >> addMore;
            }
        }
        else {
            cout << "The product does not exists. Try again..." << endl;
        }
    }
    return productCount;
}

void displayProducts(ShoppingCart cart[], int productCount) {
    double total = 0;
    cout << "------- Ordered Products ---------" << endl;
    for (int i = 0; i < productCount; ++i) {
        cout << "---Item " << i + 1 << endl;
        cout << "Product ID: " << cart[i].product_id << endl;
        cout << "Price: " << cart[i].price << endl;
        cout << "Quantity: " << cart[i].quantity << endl;
    }
    cout << "----------------------------------" << endl;
    for (int i = 0; i < productCount; ++i) {
        total += cart[i].price * cart[i].quantity;
    }
    int cents = static_cast<int>(total * 100) % 10;
    cout << "Total: " << total << endl;
}

int checkout(Connection* conn, ShoppingCart cart[], int customerId, int productCount) {
    char choice;
    bool validInput = false;
    do {
        cout << "Would you like to checkout? (Y/y or N/n) ";
        cin >> choice;
        if (toupper(choice) == 'Y' || toupper(choice) == 'N') {
            validInput = true;
        }
        else {
            cout << "Wrong input. Try again..." << endl;
        }
    } while (!validInput);
    if (toupper(choice) == 'N') {
        cout << "The order is cancelled." << endl;
        return 0;
    }
    int orderId = 0;
    try {
        Statement* stmt = conn->createStatement();
        stmt->setSQL("BEGIN add_order(:1, :2); END;");
        stmt->setInt(1, customerId);
        stmt->registerOutParam(2, Type::OCCIINT);
        stmt->executeUpdate();
        orderId = stmt->getInt(2);
        conn->terminateStatement(stmt);
        for (int i = 0; i < productCount; ++i) {
            stmt = conn->createStatement();
            stmt->setSQL("BEGIN add_order_item(:1, :2, :3, :4, :5); END;");
            stmt->setInt(1, orderId);
            stmt->setInt(2, i + 1);
            stmt->setInt(3, cart[i].product_id);
            stmt->setInt(4, cart[i].quantity);
            stmt->setDouble(5, cart[i].price);
            stmt->executeUpdate();
            conn->terminateStatement(stmt);
        }
        cout << "The order is successfully completed." << endl;
    }
    catch (SQLException& e) {
        cout << e.getErrorCode() << ": " << e.getMessage() << endl;
        return 0;
    }
    return 1;
}

void displayOrderStatus(Connection* conn, int orderId, int customerId) {
    try {
        Statement* stmt = conn->createStatement();
        stmt->setSQL("BEGIN customer_order(:1, :2); END;");
        stmt->setInt(1, customerId);
        stmt->setInt(2, orderId);
        stmt->registerOutParam(2, Type::OCCIINT);
        stmt->executeUpdate();
        if (stmt->getInt(2) == 0) {
            cout << "Order ID is not valid." << endl;
            conn->terminateStatement(stmt);
            return;
        }
        conn->terminateStatement(stmt);
        stmt = conn->createStatement();
        stmt->setSQL("BEGIN display_order_status(:1, :2); END;");
        stmt->setInt(1, orderId);
        stmt->registerOutParam(2, Type::OCCISTRING, 50);
        stmt->executeUpdate();
        string status = stmt->getString(2);
        if (status.empty()) {
            cout << "Order does not exist." << endl;
        }
        else {
            cout << "Order is " << status << "." << endl;
        }
        conn->terminateStatement(stmt);
    }
    catch (SQLException& e) {
        cout << e.getErrorCode() << ": " << e.getMessage() << endl;
    }
}

void cancelOrder(Connection* conn, int orderId, int customerId) {
    try {
        Statement* stmt = conn->createStatement();
        stmt->setSQL("BEGIN customer_order(:1, :2); END;");
        stmt->setInt(1, customerId);
        stmt->setInt(2, orderId);
        stmt->registerOutParam(2, Type::OCCIINT);
        stmt->executeUpdate();
        if (stmt->getInt(2) == 0) {
            cout << "Order ID is not valid." << endl;
            conn->terminateStatement(stmt);
            return;
        }
        conn->terminateStatement(stmt);
        stmt = conn->createStatement();
        stmt->setSQL("BEGIN cancel_order(:1, :2); END;");
        stmt->setInt(1, orderId);
        stmt->registerOutParam(2, Type::OCCIINT);
        stmt->executeUpdate();
        if (stmt->getInt(2) == 1)
            cout << "Order is canceled." << endl;
        else
            cout << "Order does not exist." << endl;
        conn->terminateStatement(stmt);
    }
    catch (SQLException& e) {
        cout << e.getErrorCode() << ": " << e.getMessage() << endl;
    }
}
