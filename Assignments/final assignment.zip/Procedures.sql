-- Procedure to find a customer by ID
CREATE OR REPLACE PROCEDURE find_customer (
    customer_id IN NUMBER, 
    found OUT NUMBER
) AS
    v_customer_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_customer_count
    FROM customers
    WHERE customer_id = find_customer.customer_id;
    
    IF v_customer_count > 0 THEN
        found := 1;
    ELSE
        found := 0;
    END IF;
EXCEPTION
    WHEN no_data_found THEN
        found := 0;
    WHEN too_many_rows THEN
        DBMS_OUTPUT.PUT_LINE('Error: Multiple customers found with the same ID.');
        found := 0;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        found := 0;
END find_customer;
/

DECLARE
    v_customer_id NUMBER := 1000; -- Replace with the customer ID you want to test
    v_found       NUMBER;
BEGIN
    find_customer(v_customer_id, v_found);
    
    IF v_found = 1 THEN
        DBMS_OUTPUT.PUT_LINE('Customer with ID ' || v_customer_id || ' exists.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Customer with ID ' || v_customer_id || ' does not exist.');
    END IF;
END;
/
SET SERVEROUTPUT ON;



-- Procedure to find a product and get its name and price
CREATE OR REPLACE PROCEDURE find_product (
    productId IN NUMBER,
    productName OUT products.product_name%TYPE,
    price OUT products.list_price%TYPE
) AS
    v_category_id products.category_id%TYPE;
    v_current_month NUMBER;
BEGIN
    SELECT product_name, list_price, category_id
    INTO productName, price, v_category_id
    FROM products
    WHERE product_id = productId;
    
    -- Check if it's November or December for discount on categories 2 and 5
    v_current_month := EXTRACT(MONTH FROM SYSDATE);
    
    IF (v_current_month IN (11, 12)) AND (v_category_id IN (2, 5)) THEN
        -- Apply 10% discount
        price := price * 0.9;
    END IF;
EXCEPTION
    WHEN no_data_found THEN
        productName := NULL;
        price := 0;
    WHEN too_many_rows THEN
        DBMS_OUTPUT.PUT_LINE('Error: Multiple products found with the same ID.');
        productName := NULL;
        price := 0;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        productName := NULL;
        price := 0;
END find_product;
/
DECLARE
    v_product_id   NUMBER := 44; -- Replace with an existing product_id
    v_product_name products.product_name%TYPE;
    v_price        products.list_price%TYPE;
BEGIN
    find_product(v_product_id, v_product_name, v_price);
    
    DBMS_OUTPUT.PUT_LINE('Product Name: ' || NVL(v_product_name, 'Not found'));
    DBMS_OUTPUT.PUT_LINE('Product Price: ' || TO_CHAR(v_price, '9990.99'));
END;
/
SET SERVEROUTPUT ON;

-- Function to generate a new order ID-----------------------------------------------------------
CREATE OR REPLACE FUNCTION generate_order_id
RETURN NUMBER IS
    v_max_id NUMBER;
BEGIN
    SELECT NVL(MAX(order_id), 0) + 1
    INTO v_max_id
    FROM orders;
    
    RETURN v_max_id;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error generating order ID: ' || SQLERRM);
        RETURN 0;
END generate_order_id;
/

-- Procedure to add a new order
CREATE OR REPLACE PROCEDURE add_order (
    customer_id IN NUMBER,
    new_order_id OUT NUMBER
) AS
BEGIN
    -- Generate new order ID
    new_order_id := generate_order_id();
    
    -- Insert new order
    INSERT INTO orders (
        order_id,
        customer_id,
        status,
        salesman_id,
        order_date
    ) VALUES (
        new_order_id,
        customer_id,
        'Shipped',
        56,
        SYSDATE
    );
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error adding order: ' || SQLERRM);
        new_order_id := 0;
        ROLLBACK;
END add_order;
/

-- Procedure to add an order item
CREATE OR REPLACE PROCEDURE add_order_item (
    orderId IN order_items.order_id%TYPE,
    itemId IN order_items.item_id%TYPE,
    productId IN order_items.product_id%TYPE,
    quantity IN order_items.quantity%TYPE,
    price IN order_items.unit_price%TYPE
) AS
BEGIN
    INSERT INTO order_items (
        order_id,
        item_id,
        product_id,
        quantity,
        unit_price
    ) VALUES (
        orderId,
        itemId,
        productId,
        quantity,
        price
    );
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error adding order item: ' || SQLERRM);
        ROLLBACK;
END add_order_item;
/
BEGIN
    add_order_item(
        orderId   => 1001,        -- Replace with a valid order_id
        itemId    => 1,           -- Use the next item number in the order
        productId => 205,         -- Replace with a valid product_id
        quantity  => 2,           -- Quantity of the product
        price     => 49.99        -- Unit price of the product
    );
    
    DBMS_OUTPUT.PUT_LINE('Order item added successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Failed to add order item: ' || SQLERRM);
END;
/
SET SERVEROUTPUT ON;

-- Procedure to verify customer's order
CREATE OR REPLACE PROCEDURE customer_order (
    customerId IN NUMBER,
    orderId IN OUT NUMBER
) AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO v_count
    FROM orders
    WHERE order_id = orderId AND customer_id = customerId;
    
    IF v_count = 0 THEN
        orderId := 0;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error verifying customer order: ' || SQLERRM);
        orderId := 0;
END customer_order;
/

-- Procedure to display order status
CREATE OR REPLACE PROCEDURE display_order_status (
    orderId IN NUMBER,
    status OUT orders.status%TYPE
) AS
BEGIN
    SELECT status
    INTO status
    FROM orders
    WHERE order_id = orderId;
EXCEPTION
    WHEN no_data_found THEN
        status := NULL;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error retrieving order status: ' || SQLERRM);
        status := NULL;
END display_order_status;
/
DECLARE
    v_order_id NUMBER := 44; -- Replace with an existing order_id
    v_status   orders.status%TYPE;
BEGIN
    display_order_status(v_order_id, v_status);

    IF v_status IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Order Status for Order ID ' || v_order_id || ': ' || v_status);
    ELSE
        DBMS_OUTPUT.PUT_LINE('No status found for Order ID ' || v_order_id);
    END IF;
END;
/
SET SERVEROUTPUT ON;

-- Procedure to cancel an order
CREATE OR REPLACE PROCEDURE cancel_order (
    orderId IN NUMBER,
    cancel OUT NUMBER
) AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO v_count
    FROM orders
    WHERE order_id = orderId;
    
    IF v_count > 0 THEN
        UPDATE orders
        SET status = 'Canceled'
        WHERE order_id = orderId;
        
        cancel := 1;
        COMMIT;
    ELSE
        cancel := 0;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error canceling order: ' || SQLERRM);
        cancel := 0;
        ROLLBACK;
END cancel_order;
/